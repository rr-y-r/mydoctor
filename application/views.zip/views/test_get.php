<? foreach($diagnosis_data as $row): ?>
<?=$row['diagnosis']; ?><br>
<? endforeach; ?>