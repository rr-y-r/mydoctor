<!DOCTYPE html>
<html lang="en">
	<head>
        <? $this->load->view('includes/header');?>
    </head>
    <body>
        <nav class="navbar navbar-default">

            <div class="navbar-header">
              <a class="navbar-brand" href="#">
                <img alt="Brand" src="<?=base_url('assets/images/logo2.png'); ?>" style="width:180px;height:50px;margin-top:-15px;margin-left:-15px;">
              </a>
                
                
          </div>
            <p class="navbar-text navbar-right">Selamat Datang, <a href="login/logout" class="navbar-link"><?=$this->session->userdata('nama');?></a></p>
        </nav>
        
        <div class="col-md-10 col-md-offset-1">
<button class="btn btn-success" data-toggle="modal" data-target="#TambahDataDiagnosa"><span class="glyphicon glyphicon-plus"></span> Tambah Data Diagnosa</button>
            <br>
            <br>
        <table class="table table-striped table-bordered table-hover" border="1" style="width:100%" id="gejalaTab">
            <thead>
                <tr> 
                    <th>ID Diagnosa</th> 
                    <th>Diagnosis</th>
                    <th>q1</th>
                    <th>q2</th> 
                    <th>q3</th> 
                    <th>q4</th> 
                    <th>q5</th> 
                    <th>Pengaturan</th> 
                </tr> 
            </thead>
            <tbody>
                <? for($i=0;$i<count($id_result);$i++): ?>
                <tr>
                    <td><?=$id_result[$i];?></td>
                    <td><?=$id_diagnosis[$i];?></td>
                    <td><?=$q1[$i];?></td>
                    <td><?=$q2[$i];?></td>
                    <td><?=$q3[$i];?></td>
                    <td><?=$q4[$i];?></td>
                    <td><?=$q5[$i];?></td>
                    <td><button class="btn btn-info"><span class="glyphicon glyphicon-pencil"></span> EDIT</button></td>
                </tr>

                <? endfor;?>
                
            </tbody>
        </table>
            
        <div class="modal fade" id="TambahDataDiagnosa" tabindex="-1" role="dialog" aria-labelledby="TambahDataDiagnosa" aria-hidden="true">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close" ><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Tambah Data Diagnosa</h4>
              </div>
              <div class="modal-body">
                  <div class="container-fluid">

                <form class="formAddDiagnosa" role="form" accept-charset="utf-8">
                    
                     <div class="form-group col-sm-6">
                         <label>Nama Diagnosis</label>
                         <input class="form-control" name="diagnosis" type="text" placeholder="Nama Penyakit"/>
          
                    
                         <label>Deskripsi Diagnosis</label>
                        <textarea class="form-control" rows="3"  name="deskripsi" type="text" placeholder="Deskripsi Penyakit"></textarea>
                    
    
                         <label>Tindakan Awal Diagnosis</label>
                        <textarea class="form-control" rows="3"  name="tindak_awal" type="text" placeholder="Deskripsi Tindakan Awal Penyakit"></textarea>
                                        
                         <label>Tindakan Lanjutan Diagnosis</label>
                        <textarea class="form-control" rows="3"  name="tindak_lanjut" type="text" placeholder="Deskripsi Tindakan Lanjutan Penyakit"></textarea>
                    
        
                         <label>Keterangan Tambahan Diagnosis</label>
                        <textarea class="form-control" rows="3"  name="ket_tambahan" type="text" placeholder="Deskripsi Keterangan Penyakit"></textarea>
                    

                         <label>Tindakan Awal Diagnosis</label>
                        <textarea class="form-control" rows="3"  name="tindak_awal" type="text" placeholder="Deskripsi Tindakan Awal Penyakit"></textarea>
                    </div>
                    <div class="form-group col-sm-6">
                         <label>Gejala Pertama</label>
                         <input class="form-control" name="q1" type="text" placeholder="Jenis Gejala Pertama"/>
                        <br>
                    
                         <label>Gejala Kedua</label>
                        <input class="form-control"  name="q2" type="text" placeholder="Jenis Gejala kedua"/>
                    <br>
    
                         <label>Gejala Ketiga</label>
                        <input class="form-control"  name="q3" type="text" placeholder="Jenis Gejala Ketiga"/>
                        <br>                
                         <label>Gejala Keempat</label>
                        <input class="form-control" name="q4" type="text" placeholder="Jenis Gejala Keempat"/>
                    <br>
        
                         <label>Gejala Kelima</label>
                        <input class="form-control"  name="q5" type="text" placeholder="Jenis Gejala Kelima"/>
                    
                    </div>
                    

                <div id="addSuccess" class="row" style="display: none">
                      <div id="addSuccessMessage" class="alert alert-info text-center"></div>
                </div>
                <div id="addError" class="row" style="display: none">
                      <div id="addErrorMessage" class="alert alert-danger text-center"></div>
                </div>
                <button type="submit" id="formSubmit" class="btn btn-success btn-lg pull-right col-md-6">Submit</button>
                </form>

              </div>
               </div>
            </div>
          </div>
        </div>
                        
</div>
    <script src="<?=base_url('assets/js/jquery.js'); ?>"></script>
    <script src="<?=base_url('assets/js/bootstrap.js'); ?>"></script>
    <script>
    $( document ).ready(function(e){
        
    });
    </script>

    </body>
</html>