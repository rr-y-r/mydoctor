<? $this->load->view('includes/header');?>
<body>

<div class="login-form">
    <div class="col-md-offset-3 col-md-6 align-center">
  <form class="form-signin" id="form-signin" role="form" action="<?=site_url('Login/loginCheck'); ?>" method="post" accept-charset="utf-8">
    <h2 class="form-signin-heading" style="color:#fff;">Login</h2>
    <input class="form-control" name="username" placeholder="username" required maxlength="40" >
    <input class="form-control" type="password" name="password" placeholder="password" required maxlength="20" />
      <br>
    <button class="btn btn-lg btn-primary btn-block" style="background-color:#FF6666;" type="submit">SIGN IN</button>
      
    <? if (isset($error)): ?>
      <div class="row">

      <div class="alert alert-error">
        <strong>Login</strong> gagal !, periksa data anda kembali
      </div>

      </div>
      
      <? endif; ?>
</form>


</body>



