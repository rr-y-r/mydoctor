<?php

class DataModel extends CI_Model 
{
    
    function __construct()
    {
        parent::__construct();
    }
    
    function getDataStruct($id)
    {
        $data_input = $this->db
            ->get_where('training_data', array('id_training' => $id))
            ->result_array();

        return $data_input;
    }
    
    function insertTDat($data)
    {
        $this->db->insert('training_data',$data);
        return TRUE;
    }
    
    function getDataDiagnosis_all(){
        return $this->db->select('')
            ->get('diagnosis')
            ->result_array();
    }
    
    function getDataGejala_all(){
        return $this->db->select('')
            ->get('gejala')
            ->result_array();
    }
    
    /*
    function getDiagnosis_byToggle($id){
        $data = $this->db->get_where('tpejabat', array('nama' => $assesor))->row();
        return $data->jabatan;
    }
    */
    
    function getDiagnosis_byTrigger($data){
        return $this->db->get_where('rdata',$data)
            ->result_array();
    }
    
    function get_result($data){
        $id = $this->db->get_where('rdata',$data)
            ->row('id_diagnosis');
        
        $result = $this->db->get_where('diagnosis',array('id_diagnosis'=>$id))->result_array();
        
        return $result;
    }
    
    function init_grid(){
        return $this->db->select('q1')
            ->get('rdata')
            ->result_array();
    }
    
    function get_rdata(){
        return $this->db->select('*')
            ->get('rdata')
            ->result_array();
    }
    
    /*
    
    $this->db->select('k.*');
        $this->db->from('komite_karir k');
        $this->db->join('user u', 'k.nik_kontributor=u.nik ','left');
        $this->db->where('u.department',$group);
        
        return $this->db->get()->result_array();
        
        */
    function get_gejalaByID($id){
        if($id==0){
            return 0;
        }else{
            $row = $this->db->get_where('gejala', array('id_gejala' => $id))->row(1);
            return $row->gejala;
        }
    }
    
    function get_diagnosisByID($id){
        $row = $this->db->get_where('diagnosis', array('id_diagnosis' => $id))->row();
            return $row->diagnosis;
    }
    
}