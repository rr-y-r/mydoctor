<?php if (! defined('BASEPATH')) exit('No direct script access allowed');

class Dokter extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        
        if (!$this->session->userdata('is_logged_in')) 
        {
            $this->session->sess_destroy();
            redirect('login');
        }

        $this->load->model('userModel');
        $this->load->model('dataModel');
    }
    
    public function index()
    {  

        $data = array();
        $id_result = array();
        $id_diagnosis = array();
        $q1 = array();
            $q2 = array();
            $q3 = array();
            $q4 = array();
            $q5 = array();
        $rdata = $this->dataModel->get_rdata();
       // $d_data = $this->dataModel->getDataDiagnosis_all();
        //$g_data =  $this->dataModel->getDataGejala_all();
        
        
        foreach($rdata as $id_q => $row_id){
            foreach($row_id as $column_id => $value_id){
                if($column_id == 'id_result'){
                    $id_result[] = $value_id;

                }
                if($column_id == 'id_diagnosis'){
                    //$data[] = array($column_id=>$this->dataModel->get_diagnosisByID($value_id));
                    $id_diagnosis[] = $this->dataModel->get_diagnosisByID($value_id);

                }
                if($column_id == 'q1'){
                    //$data[] = array($column_id=> $this->dataModel->get_gejalaByID($value_id));
                    $q1[] = $this->dataModel->get_gejalaByID($value_id);

                }
                if($column_id == 'q2'){
                    //$data[] = array($column_id=>$this->dataModel->get_gejalaByID($value_id));
                    $q2[] = $this->dataModel->get_gejalaByID($value_id);

                }
                if($column_id == 'q3'){
                    //$data[] = array($column_id=>$this->dataModel->get_gejalaByID($value_id));
                    $q3[] = $this->dataModel->get_gejalaByID($value_id);

                }
                if($column_id == 'q4'){
                    //$data[] = array($column_id=>$this->dataModel->get_gejalaByID($value_id));
                    $q4[] = $this->dataModel->get_gejalaByID($value_id);

                }
                if($column_id == 'q5'){
                    //$data[] = array($column_id=>$this->dataModel->get_gejalaByID($value_id));
                    $q5[] = $this->dataModel->get_gejalaByID($value_id);

                }
                
            }
            
        }
        
        //echo json_encode(array('data_rdat'=>$data));
        
        $this->load->view('dokter',array('id_result'=>$id_result,
                                        'id_diagnosis'=>$id_diagnosis,
                                        'q1'=>$q1,
                                        'q2'=>$q2,
                                        'q3'=>$q3,
                                        'q4'=>$q4,
                                        'q5'=>$q5));

    }
    
    function initial_data(){
       $id=0;$id_d=0;$q1=0;$q2=0;$q3=0;$q4=0;$q5=0;
        $data = array();
        $new_data = array();
        
        $rdata = $this->dataModel->get_rdata();
       // $d_data = $this->dataModel->getDataDiagnosis_all();
        //$g_data =  $this->dataModel->getDataGejala_all();
        
        
        foreach($rdata as $id_q => $row_id){
            foreach($row_id as $column_id => $value_id){
                if($column_id == 'id_result'){
                    $data[$id][$column_id] = $value_id;
                    
                }
                if($column_id == 'id_diagnosis'){
                    //$data[] = array($column_id=>$this->dataModel->get_diagnosisByID($value_id));
                    $data[$id][$column_id] = $this->dataModel->get_diagnosisByID($value_id);
                    //$id_d++;
                }
                if($column_id == 'q1'){
                    //$data[] = array($column_id=> $this->dataModel->get_gejalaByID($value_id));
                    $data[$id][$column_id] = $this->dataModel->get_gejalaByID($value_id);
                    //$q1++;
                }
                if($column_id == 'q2'){
                    //$data[] = array($column_id=>$this->dataModel->get_gejalaByID($value_id));
                    $data[$id][$column_id] = $this->dataModel->get_gejalaByID($value_id);
                    //$q2++;
                }
                if($column_id == 'q3'){
                    //$data[] = array($column_id=>$this->dataModel->get_gejalaByID($value_id));
                    $data[][$column_id] = $this->dataModel->get_gejalaByID($value_id);
                    //$q3++;
                }
                if($column_id == 'q4'){
                    //$data[] = array($column_id=>$this->dataModel->get_gejalaByID($value_id));
                    $data[$id][$column_id] = $this->dataModel->get_gejalaByID($value_id);
                    //$q4++;
                }
                if($column_id == 'q5'){
                    //$data[] = array($column_id=>$this->dataModel->get_gejalaByID($value_id));
                    $data[$id][$column_id] = $this->dataModel->get_gejalaByID($value_id);
                    //$q5++;
                }
                $id++;
            }
            
        }
        
        echo json_encode(array('data_r'=>array('data_rdat'=>$data)));
        //echo json_encode(array('data_rdat'=>$new_data));
    }
    
    function get_rdata(){
        $rdata = $this->dataModel->get_rdata();
        echo json_encode(array('data_rdat'=>$rdata));
    }
    
    function get_gejalaByID($id){
        echo $this->dataModel->get_gejalaByID($id);
    }
        
    function get_diagnosisByID($id){
        echo $this->dataModel->get_diagnosisByID($id);
    }
    
    function get_data_diagnosa()
    {
        $d_data = $this->dataModel->getDataDiagnosis_all();
        echo json_encode($d_data);
    }
    
}